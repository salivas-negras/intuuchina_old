<?php
/**
 *  @package     AkeebaFEF
 *  @copyright Copyright (c)2017-2018 Nicholas K. Dionysopoulos / Akeeba Ltd
 *  @license     GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die;

define('AKEEBAFEF_VERSION', '1.0.3');
define('AKEEBAFEF_DATE', '2018-03-26');
